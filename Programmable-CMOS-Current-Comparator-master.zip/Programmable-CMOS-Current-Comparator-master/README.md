# LOWER POWER CURRENT PROGRAMMABLE CMOS COMPARATOR WITH HYSTERESIS

This main aim of this project is to develop a Programmable CMOS current coparator with Hysteresis, i.e., the reference current should be adjustable with a wide range of values without altering the (W/L) values of the MOS transistors. The key idea in developing the circuit is to find parameters in the circuit which are linked directly in the current equation such as a voltage other than the physical parameters. So, we develop a equation in which reference current is a function of a voltage rather than the physical parameters.

# Getting a glance of IP:

This repository has files needed to design and implement a Programmable CMOS current comparator.

1) Download the ```Understanding CMOS current Comparator doc``` provided in this repository.
2) Carefully study it to understand the use of this IP and check the references section for the research papers and weblinks for further information on the IP.
3) Download and read the ```Applications of Current Comparator in VLSI``` to understand the practical uses of a current comparator.

# Setting up the simulator:
1) Download NI Multisim 14.1 from https://softfamous.com/ni-multisim/download/
2) Click on `Download from ni.com -> GET STUDENT DOWNLOAD  ` 
<br/>
  <img align ="left" src="https://user-images.githubusercontent.com/66675990/84494289-d9744800-acc6-11ea-91a3-938bc8146741.JPG" width= "300" > 
 <img  src="https://user-images.githubusercontent.com/66675990/84496533-b9df1e80-acca-11ea-9606-0a4dd1d316c9.JPG" width="300" >
   <br/>  
        
3) Unzip the compressed folder and save in preferred folder.   <br/>     
4) Open `setup.exe` file and install.

NI Multisim can be downloaded only on windows OS. For MAC OS or LINUX users, Windows OS have to be installed using virtual machine or can use online MULTISIM LIVE https://www.multisim.com/

# Overview of the schematic:
1) Download the file named ``` Programmable current commparator.ms14``` in this repository.
1) Open the software and go the  ```File -> Open``` and browse for the downloaded file mentioned above and click open.
1) Once the steps mentioned above are done in the same order, a schematic circuit opens, which is first circuit required in the process of simulation.
2) You can see that all the components and the Voltage and Current sources are clearly annotated.
3) M1-M7 are the MOS Transistors and the values just adjacent to them are the channel length and width of the MOS respectively.
4) You can understand the working of the circuit by reading the CMOS Comparator Simulations doc file provided in this repository.

# Running the simulations:
The plot images and a detailed report doc named ```Understanding Simulations``` is uploaded in the repository.
## 1. Reference current characterstic plot as a function of the reference voltage.
1) Now go to ```Simulate -> Analyses``` and simulation and select ```Interactive``` mode of simulation.
2) Click ```F5``` to run the simulation.
3) You can notice the reference current genarated in current measuring probe 2 mentioned as PR2 in the circuit.

![capture8](https://user-images.githubusercontent.com/45147578/84508852-8e672e80-ace0-11ea-858e-8cf75482f527.JPG)

4) Make a note of it and you can verify it with the equation provided in the  CMOS Comparator Simulations doc file.
5) Now again go to ```Simulate -> Analyses``` and simulation and change it to ```DC Sweep``` and choose source as ```VRef``` and uncheck ```Use source 2``` box.
6) Choose the start value as ```0V```, stop value as ```5V```, and Increment as ```0.25V```. 
![Capture5](https://user-images.githubusercontent.com/45147578/84507134-fa946300-acdd-11ea-8106-90aa1bbce15a.JPG)

7) Go to Output which is present just beside the Analyses parameters tab and check for ```I(PR2)``` in the right coloumn, this is the parameter which is to used in the plot.
8) Use Remove to delete any other parameters which are present on the right coloumn. Make sure that you select 'all variables' in the drop down box present in the first coloumn.
![Capture6](https://user-images.githubusercontent.com/45147578/84507091-ec464700-acdd-11ea-85ad-55004e8963dc.JPG)

9) Now click ```Run```.

You can see a graph plotted, which is plot of I(PR2) vs Vref plot with both the axes named as current. Its just a label and can be changed by double clicking on the label and changing the names to ```Vref``` and ```Iref``` for X and Y axes respectively. 

## 2. Comparator characterstics plot (Output voltage vs Input current):
As we have calculated the reference current and plotted it as a function of the reference voltage, now we need to check the working of the comparator for a given reference current. So we plot the output voltage of the comparator with respect to the change in input current. As the reference current genarated for a reference voltage of ```1.5V``` is ```23.4uA```, we change input current from ```5uA``` to ```30uA``` and check the output voltage.
1) Go to Simulate -> Analyses and simulation and change it to DC Sweep and choose source as I1 and uncheck ```Use source 2``` box.
2) Change the starting value as ```5e-006```, stop value as ```3e-005```, and step value as ```1e-007```.
![Capture4](https://user-images.githubusercontent.com/45147578/84507253-26174d80-acde-11ea-9e4d-8e251be79bc0.JPG)

3) Go to Output which is present just beside the Analyses parameters tab and remove I(PR2) and add V(PR1) from the left coloumn of variables.
![Capture7](https://user-images.githubusercontent.com/45147578/84508206-96729e80-acdf-11ea-977d-67d8b41dd80f.JPG)

4) Click run.

You can see a plot which is called the characterstics curve. You can change the labels of the X-axis and Y-axis as meentioned above. Observe that the curve suddenly increases at a point which the reference current as the ouput suddenly changes to 5V once the input current crosses the reference current. You can place measuring cursors by clicking show cursors in the cursors coloumn on the top. Two adjustable cursors appear on the Y-axis, drag them to your required position and you can observe the values of the co-ordinates in a box below.

# Circuit for Propagation delay calculation:
1) Download the circuit for delay calculation in this repository and open in Multisim 14 in the same way as Programmable current comparator.
2) You can notice that the input current source is changed to `I2`, which is a linear peicewise incremented current source. The inputs to the source are time and current. The data is uploaded in the circuit itself and you can check the data in the file named as `data for input current` in this repository.
3) Now change the mode of simulation to `Transient` in interactive and simulations
4) Enter the stop time as ```2.5e-007``` and choose output variables as V(PR3).
![Capture](https://user-images.githubusercontent.com/45147578/84499898-20ffd180-acd1-11ea-8a46-f354d9f0415e.JPG)
![Capture2](https://user-images.githubusercontent.com/45147578/84507805-02a0d280-acdf-11ea-9129-384327a02542.JPG)
5) Click ```Run```.
 
You can see a plot of Voltage vs time, which indicates the change of the output voltage with respect to time when the input current is changing. Observe that the values in time coloumn in the `data for input current` as very small in the order of nano seconds. The delay is to be calculated in the order of nano seconds. Now place the cursors in the same way mentioned before and adjust them such that one is on the below of the rising point and the other is on the top of the peak. Note the values and the delay can be calculated using the formula mentioned in the ```Understanding Simulations``` word doc.
![Capture3](https://user-images.githubusercontent.com/45147578/84500414-1e51ac00-acd2-11ea-952b-98c9e1cf09ac.JPG)

Thus all the plots are obtained using the two circuits and those are to be analyzed to introduce the Hysteresis circuit. The plot images are in the repository.

Contact Information
====================
- R.S.S.K.S.DEEPAK
 B.tech Electronics & Communications, NIT Rourkela
  satyadeepak1999@gmail.com
- KUNAL GHOSH 
 Director, VSD Corp. Pvt. Ltd. 
  kunalpghosh@gmail.com
- PHILIPP GÜHRING 
Software Architect at LibreSilicon Association
  pg@futureware.at
 - Dr. GAURAV TRIVEDI 
 Co-Principal Investigator, EICT Academy,   
  and Associative Professor, EEE Department, IIT Guwahati
  trivedi@iitg.ac.in

